/**
 * TreeNode class for MorseCodeTree.
 *
 * @param <T> The type of data stored in the TreeNode.
 */
public class TreeNode<T> {
    private T data;
    private TreeNode<T> left;
    private TreeNode<T> right;

    /**
     * Creates a new TreeNode with left and right child set to null and data set to the dataNode.
     *
     * @param dataNode The data to be stored in the TreeNode.
     */
    public TreeNode(T dataNode) {
        this.data = dataNode;
        this.left = null;
        this.right = null;
    }

   
    
    /**
     * Creates a new TreeNode by making a deep copy of the provided node.
     *
     * @param node The TreeNode to make a deep copy of.
     */
    public TreeNode(TreeNode<T> node) {
        if (node != null) {
            this.data = node.getData();

            if (node.getLeft() != null) {
                this.left = new TreeNode<>(node.getLeft());
            } else {
                this.left = null;
            }

            if (node.getRight() != null) {
                this.right = new TreeNode<>(node.getRight());
            } else {
                this.right = null;
            }
        } else {
            this.data = null;
            this.left = null;
            this.right = null;
        }
    }

    /**
     * Get the data stored in this TreeNode.
     *
     * @return The data stored in this TreeNode.
     */
    public T getData() {
        return data;
    }
    public void setLeft(TreeNode<T> left) {
		this.left = left;
	}
	
	public void setRight(TreeNode<T> right) {
		this.right = right;
	}

    /**
     * Get the left child of this TreeNode.
     *
     * @return The left child TreeNode.
     */
    public TreeNode<T> getLeft() {
        return left;
    }

    /**
     * Get the right child of this TreeNode.
     *
     * @return The right child TreeNode.
     */
    public TreeNode<T> getRight() {
        return right;
    }
}
