import java.util.ArrayList;

/**
 * MorseCodeTree: A generic linked binary tree that represents Morse code.
 * It implements the LinkedConverterTreeInterface with String data.
 * Nodes are added based on their Morse code value.
 *
 * The Morse code is interpreted as follows:
 * - '.' (dot) means to traverse left
 * - '-' (dash) means to traverse right
 *
 * The constructor initializes the tree by calling the buildTree method.
 *
 * @author Juan Prieto
 * 
 */

public class MorseCodeTree implements LinkedConverterTreeInterface<String> {

    // Private member representing the root of the MorseCodeTree
    private TreeNode<String> root;

    /**
     * Constructor for MorseCodeTree.
     * Initializes the tree by calling the buildTree method.
     */
    public MorseCodeTree() {
        buildTree();
    }

    /**
     * Returns a reference to the root of the tree.
     *
     * @return Reference to the root of the tree.
     */
    @Override
    public TreeNode<String> getRoot() {
        return root;
    }

    /**
     * Sets the root of the tree.
     *
     * @param newNode The new root node.
     */
    @Override
    public void setRoot(TreeNode<String> newNode) {
        root = newNode;
    }

    /**
     * Adds a node to the correct position in the tree based on the code.
     * This method calls the recursive method addNode.
     *
     * @param code   The Morse code for the new node.
     * @param letter The data of the new TreeNode to be added.
     */
    @Override
    public void insert(String code, String letter) 
    {
        addNode(root, code, letter);
    }

    /**
     * Recursive method to add a node to the tree based on the code.
     *
     * @param root   The root of the tree for this particular recursive instance of addNode.
     * @param code   The Morse code for this particular recursive instance of addNode.
     * @param letter The data of the new TreeNode to be added.
     */
    @Override
    public void addNode(TreeNode<String> root, String code, String letter) {
        if (code.length() == 1) {
            if (code.equals(".")) {
                root.setLeft(new TreeNode<>(letter));
            } else if (code.equals("-")) {
                root.setRight(new TreeNode<>(letter));
            }
        } else {
            if (code.charAt(0) == '.') {
                if (root.getLeft() == null) {
                    root.setLeft(new TreeNode<>(letter));
                }
                addNode(root.getLeft(), code.substring(1), letter);
            } else if (code.charAt(0) == '-') {
                if (root.getRight() == null) {
                    root.setRight(new TreeNode<>(letter));
                }
                addNode(root.getRight(), code.substring(1), letter);
            }
        }
    }

    /**
     * Fetches data in the tree based on the Morse code.
     * This method calls the recursive method fetchNode.
     *
     * @param code The Morse code that describes the traversals within the tree.
     * @return The data that corresponds to the code.
     */
    @Override
    public String fetch(String code) {
        return fetchNode(root, code);
    }

    /**
     * Recursive method to fetch the data of the TreeNode that corresponds with the code.
     *
     * @param root The root of the tree for this particular recursive instance of fetchNode.
     * @param code The Morse code for this particular recursive instance of fetchNode.
     * @return The data corresponding to the code.
     */
 
    @Override
    public String fetchNode(TreeNode<String> root, String code) {
    	        if (root == null) {
    	            // If the root is null, there's nothing to fetch
    	            return null;
    	        }

    	        if (code.isEmpty()) {
    	            // If the code is empty, return the data of the current node
    	            return root.getData();
    	        }

    	        char direction = code.charAt(0);
    	        String remainingCode = code.substring(1);

    	        if (direction == '.') {
    	            // Traverse to the left
    	            return fetchNode(root.getLeft(), remainingCode);
    	        } else if (direction == '-') {
    	            // Traverse to the right
    	            return fetchNode(root.getRight(), remainingCode);
    	        } else {
    	            // Handle invalid direction (assuming only '.' and '-' are valid)
    	            throw new IllegalArgumentException("Invalid direction: " + direction);
    	        }
    	    }

    /**
     * Not supported for MorseCodeTree. Throws UnsupportedOperationException.
     *
     * @param data Data of the node to be deleted.
     * @return Reference to the current tree.
     * @throws UnsupportedOperationException Always thrown since delete operation is not supported.
     */
    @Override
    public LinkedConverterTreeInterface<String> delete(String data) throws UnsupportedOperationException {
        throw new UnsupportedOperationException("Delete operation is not supported in MorseCodeTree");
    }

    /**
     * Not supported for MorseCodeTree. Throws UnsupportedOperationException.
     *
     * @return Reference to the current tree.
     * @throws UnsupportedOperationException Always thrown since update operation is not supported.
     */
    @Override
    public LinkedConverterTreeInterface<String> update() throws UnsupportedOperationException {
        throw new UnsupportedOperationException("Update operation is not supported in MorseCodeTree");
    }

    /**
     * Builds the MorseCodeTree by inserting nodes level by level based on the Morse code.
     */
    @Override
    public void buildTree() {
    	root = new TreeNode("");
    	insert(".-", "a");
    	insert("-...", "b");
    	insert("-.-.", "c");
    	insert("-..", "d");
    	insert(".", "e");
    	insert("..-.", "f");
    	insert("--.", "g");
    	insert("....", "h");
    	insert("..", "i");
    	insert(".---", "j");
    	insert("-.-", "k");
    	insert(".-..", "l");
    	insert("--", "m");
    	insert("-.", "n");
    	insert("---", "o");
    	insert(".--.", "p");
    	insert("--.-", "q");
    	insert(".-.", "r");
    	insert("...", "s");
		insert("-", "t");
		insert("..-", "u");
		insert("...-", "v");
		insert(".--", "w");
		insert("-..-", "x");
		insert("-.--", "y");
		insert("--..", "z");
		

    }

    /**
     * Returns an ArrayList of the items in the linked Tree in LNR (Inorder) Traversal order.
     * Used for testing to ensure the tree is built correctly.
     *
     * @return An ArrayList of the items in the linked Tree.
     */
    @Override
    public ArrayList<String> toArrayList() {
        ArrayList<String> list = new ArrayList<>();
        LNRoutputTraversal(root, list);
        return list;
    }

    /**
     * Recursive method to put the contents of the tree in an ArrayList in LNR (Inorder) order.
     *
     * @param root The root of the tree for this particular recursive instance.
     * @param list The ArrayList that will hold the contents of the tree in LNR order.
     */
    @Override
    public void LNRoutputTraversal(TreeNode<String> root, ArrayList<String> list) {
        if (root != null) {
            // Traverse the left subtree
            LNRoutputTraversal(root.getLeft(), list);

            // Visit the root node
            list.add(root.getData());

            // Traverse the right subtree
            LNRoutputTraversal(root.getRight(), list);
        }
    }
}
