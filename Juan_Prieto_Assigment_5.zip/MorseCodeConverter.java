import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.Scanner;

/**
 * The MorseCodeConverter class provides methods to convert Morse code to English
 * using a Morse code tree.
 */
public class MorseCodeConverter {

    // Static MorseCodeTree object
    private static final MorseCodeTree morseCodeTree = new MorseCodeTree();

    /**
     * Converts Morse code from a file to English.
     *
     * @param codeFile The file containing Morse code to be converted.
     * @return The English representation of the Morse code.
     */
    public static String convertToEnglish(File codeFile) {
        try (Scanner scanner = new Scanner(codeFile)) {
            StringBuilder result = new StringBuilder();

            while (scanner.hasNext()) {
                String code = scanner.next();
                String letter = morseCodeTree.fetch(code);
                result.append(letter);
            }

            return result.toString();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return "Error reading file";
        }
    }

    /**
     * Converts Morse code string to English.
     *
     * @param code The Morse code string to be converted.
     * @return The English representation of the Morse code.
     */
    public static String convertToEnglish(String code) {
        String[] words = code.split(" / ");

        StringBuilder result = new StringBuilder();

        // Iterate through each word
        for (String word : words) {
            // Split the word into individual Morse code letters based on space (' ')
            String[] letters = word.split(" ");

            // Translate each Morse code letter to English
            for (String letter : letters) {
                result.append(morseCodeTree.fetch(letter));
            }
        }

        return result.toString().trim();
    }

    /**
     * Prints the Morse code tree in LNR order.
     *
     * @return A string representation of the Morse code tree.
     */
    public static String printTree() {
        List<String> treeList = morseCodeTree.toArrayList();

        StringBuilder output = new StringBuilder();
        for (String s : treeList) {
            output.append(s).append(" | "); // Modify the separator as needed
        }

        // Remove the trailing separator if the string is not empty
        if (output.length() > 0) {
            output.setLength(output.length() - 3);
        }

        return output.toString();
    }
}
